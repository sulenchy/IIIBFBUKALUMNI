﻿using System.Web.UI;

namespace IIIBF_BUK_ALUMNI.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}