﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using IIIBF_BUK_ALUMNI.Models;

namespace IIIBF_BUK_ALUMNI
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public IQueryable<Article> GetArticles()
        {
            var _db = new IIIBF_BUK_ALUMNI.Models.AppContext();
            IQueryable<Article> query = _db.Articles.OrderBy(d => d.DatePosted).Take(3);
            return query;
        }
    }
}