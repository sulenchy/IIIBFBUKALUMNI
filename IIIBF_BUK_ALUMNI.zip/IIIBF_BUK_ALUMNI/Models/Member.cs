﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace IIIBF_BUK_ALUMNI.Models
{
    public class Member
    {
        [ScaffoldColumn(false)]
        public int MemberID { get; set; }
        [Required, StringLength(100), Display(Name = "Email")]
        public string Email { get; set; }
        [Required, StringLength(100), Display(Name = "FirstName")]
        public string FirstName { get; set; }
        [Required, StringLength(100), Display(Name = "LastName")]
        public string LastName { get; set; }
        [Required, StringLength(10000), Display(Name = "Member Address"), DataType(DataType.MultilineText)]
        public string Address { get; set; }
        [Required, Display(Name ="Phone Number"), RegularExpression(@"\(?\d{3}\)?-? *\d{3}-? *-?\d{3} *-?\d{4}", ErrorMessage = "Invalid Phone Number")]
        public string PhoneNumber { get; set; }
        public string PassportPath { get; set; }
    }
}